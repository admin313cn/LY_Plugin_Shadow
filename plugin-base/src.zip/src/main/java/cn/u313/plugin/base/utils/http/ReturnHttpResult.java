package cn.u313.plugin.base.utils.http;

interface ReturnHttpResult {
    void clickReturnHttpResult(String message);
}
