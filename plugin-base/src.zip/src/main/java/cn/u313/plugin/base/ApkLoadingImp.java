package cn.u313.plugin.base;

public class ApkLoadingImp implements ApkLoading{
    @Override
    public void download() {

    }

    @Override
    public void getPluginConfig() {

    }

    @Override
    public void getPlugin() {

    }

    @Override
    public void getDownloadUrl() {

    }
}
