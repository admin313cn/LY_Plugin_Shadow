package cn.u313.plugin.base;

import android.view.View;

import com.tencent.shadow.dynamic.host.EnterCallback;

public abstract class HostEnterCallback  {

        public void onShowLoadingView(View view) {

        }

        public void onCloseLoadingView() {

        }

        public void onEnterComplete() {

        }
}
