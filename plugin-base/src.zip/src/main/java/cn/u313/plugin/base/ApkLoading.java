package cn.u313.plugin.base;

public interface ApkLoading {
    public void download();
    public void getPluginConfig();
    public void getPlugin();
    public void getDownloadUrl();
}
